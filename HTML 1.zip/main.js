function showsidebar() {
  
  var side = document.querySelector('.sidebar');
    side.style.display='flex';
   }
   function hidesidebar() {
    var side = document.querySelector('.sidebar');
    side.style.display = 'none';
   }
   